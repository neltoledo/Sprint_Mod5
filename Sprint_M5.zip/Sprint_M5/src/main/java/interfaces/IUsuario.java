package interfaces;

import models.Usuario;

import java.util.List;

public interface IUsuario {

    public boolean guardarUsuario(Usuario usuario);
    public List<Usuario> listarUsuario();
    public Usuario obtenerUsuarioPorId(int id);
    public boolean actualizarUsuario(Usuario usuario);
}